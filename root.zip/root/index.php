<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{
    margin: 0px;
    padding: 0px;
    background: url(under-2-min.jpg)!important;
    background-size: cover!important;
    background-position: center center !important;
    background-repeat: no-repeat;
    }
@media (max-width: 477px){ 
body{
    margin: 0px;
    padding: 0px;
    background: url(under-2-mob.jpg)!important;
    background-size: contain!important;
    background-position: center center !important;
    background-repeat: no-repeat  !important;
    }
    }
</style>

</head>
<title>Qatarat</title>

<body >
<table border=0 style="height:100%; width:100%">
<tr><td style="text-align:center">
<!--<img src="under-2-min.jpg" style='width:100%'>-->
</td></tr>
</table>
</dody>
</html>