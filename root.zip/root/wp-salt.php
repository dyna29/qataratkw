<?php
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 */
define('AUTH_KEY',         'Em12ivuyPIB8LYQKVdCrQzugEqRjKz0TH62wFu4uysf9yt27pquRiJerTXmAWy2i');
define('SECURE_AUTH_KEY',  'hnqhUhvs6tXTm80rbqFKhaeN5IUtrsnEXWfhXzIdx1BNSB4iKAsNUCJUhsu7QdY8');
define('LOGGED_IN_KEY',    '8AUsdg52ne6WLnGXVnKy4DLaXSYbTHFGVec2XT1IpnTnw3LXgNhJvw8BERoEm4tA');
define('NONCE_KEY',        '3pNBbo9hMV8Bm5t4JFjWbsjmUKKTRjPUVvTyEGCdyTAs9gH0XoHDAX8incFjrqBA');
define('AUTH_SALT',        'BnGGVPxrwWh0Fca1PJicJLTPvuS45KAJpL4GvUNPeLQs3CL5au1tptzNpBis0nCY');
define('SECURE_AUTH_SALT', 'a6BD0csH1ecRjNwvai8JV9QIu6crzggKtqTgSFys13nWNgBXsc8DjTzYizwwxj2f');
define('LOGGED_IN_SALT',   'S09GR7FhoqnIMeybEI2yh8vraAhRqfqKa6qFJy8ieXpE2gEHcLJIt7fqb1zPQnxB');
define('NONCE_SALT',       '548cNfDHjCJiyEKpArqzoo9i4WMyu10cujRRBCfrXijsXnGcdnaTTGv3XVsMGDaT');
